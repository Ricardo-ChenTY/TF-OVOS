_base_ = "./base_config.py"

model = dict(
    name_path="./configs/cls_context459.txt",
    global_semantics_weight=0.25,
    mean_vector_weight=0.04,
    h_threshold=0.09,
)

dataset_type = "PascalContext459Dataset"
data_root = "/data/tianyi/TF-OVCOS/data/raw/VOCdevkit/VOC2010"

test_pipeline = [
    dict(type="LoadImageFromFile"),
    dict(type="Resize", scale=(2048, 336), keep_ratio=True),
    dict(type="MyLoadAnnotations", reduce_zero_label=False),
    dict(type="PackSegInputs"),
]

test_dataloader = dict(
    batch_size=1,
    num_workers=4,
    persistent_workers=True,
    sampler=dict(type="DefaultSampler", shuffle=False),
    dataset=dict(
        type=dataset_type,
        data_root=data_root,
        data_prefix=dict(img_path="JPEGImages", seg_map_path="annotations_detectron2/pc459_val"),
        ann_file="ImageSets/SegmentationContext/val.txt",
        pipeline=test_pipeline,
    ),
)

test_evaluator = dict(type='IoUMetric', iou_metrics=['mIoU'], output_dir='/data/tianyi/TF-OVCOS/runs/artifacts/official_predictions/cass/context459')
