# Portable qualitative assets (2026-10-12)

16 cases: eight historical mixed-dataset candidates plus eight cases used by the submitted all-ADE Figure 5. Each has input JPEG, current semantic GT PNG, target mask, vocab, four dense predictions and corrected seed-0 SAM+SigLIP prediction. Raw maps are copied byte-for-byte. `cases.json` specifies per-method label offsets, void IDs, selected class names and target provenance. Vocabulary comments and blank lines must be skipped.

Install NumPy and Pillow, then run `python render.py . --verify-only` or `python render.py . --out rendered`. No server paths, GPU, weights, dataset mounts, HF cache or network are needed. Rendered panels are audit previews, not automatically approved manuscript replacements.

For eight all-ADE cases, original ADE polygon annotations replace the missing `/private/tmp/ade_hf_rows.jsonl`. The largest matching raw-name polygon follows the old selection rule; the old HF cache itself was not recovered and byte equality to its annotations is not claimed. Dataset attribution is retained in each ADE annotation's source field. Inputs remain subject to their original dataset terms; this is a research/review subset.

COCO case 000000033707: the old flower target (ID 107) is absent in current corrected GT. `historical_gt.png` and the old target mask are included only for audit; current GT assigns ID 108 (fog) to those 42,213 pixels. Do not use the historical flower caption as current GT. Keep the all-ADE option with corrected titles, or choose a separately verified COCO case.

ADE-847 predictions are zero-based. The shelf case decodes to bookcase / drawer / bookcase / pantry for CorrCLIP / NACLIP / ProxyCLIP / SCLIP. The jacket case decodes to coat for all four. These correct label decoding only; they do not independently validate the qualitative interpretation.

The submitted PDF available during audit has no Figures 6–8. The four historical appendix candidate IDs therefore remain conditional until checked against the final appendix PDF. Signboard's selected SAM+SigLIP overlay is unchanged; the other three historical selected overlays changed.

This small bundle is NOT a backup of all predictions, datasets or model weights. Keep experiment disks until discussion ends if later rescoring or new inference may be needed.
